DWARF_IP = ""
DWARF_ID = ""
DWARF_UI = ""
CLIENT_ID = "0000DAF2-0000-1000-8000-00805F9B34FB"
# TIMEOUT_CMD for TimeOut deconnection (s) after not receiving command
# none or ommited set by defaut to 30 minutes
# set to 0 to remove Timeout : None forced deconnection
TIMEOUT_CMD = "0"
# LOG_FILE for log file, app.log if ommitted or empty; "False" to redirect to console
LOG_FILE = "astro_session.log"
# True to add debug level information on log file, if not will be Info Level
DEBUG = True
# True to add info level information on console, if not will be Notice Level
TRACE = ""